import { useState } from 'react';
import Hero from './components/Hero';
import Stats from './components/Stats';
import About from './components/About';
import Courses from './components/Courses';
import CourseDetail from './components/CourseDetail';
import Navigation from './components/Navigation';

function App() {
  const [currentCourseId, setCurrentCourseId] = useState<string | null>(null);

  const handleCourseClick = (courseId: string) => {
    setCurrentCourseId(courseId);
  };

  const handleBackToCourses = () => {
    setCurrentCourseId(null);
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8]">
      <div className="pixel-border">
        <Navigation />
        {currentCourseId ? (
          <CourseDetail courseId={currentCourseId} onBack={handleBackToCourses} />
        ) : (
          <>
            <Hero />
            <Stats />
            <About />
            <Courses onCourseClick={handleCourseClick} />
          </>
        )}
      </div>
    </div>
  );
}

export default App;
