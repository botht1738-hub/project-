function About() {
  return (
    <section className="relative px-8 py-20">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="pixel-text text-7xl mb-12 tracking-wider">
          WHAT IS<br />THIS SPACE?
        </h2>

        <div className="max-w-2xl mx-auto text-sm leading-relaxed space-y-4">
          <p>
            This website helps you organize all your courses in one intelligent dashboard.
          </p>
          <p>
            Track your progress across subjects, store notes, manage projects, and never miss a deadline.
          </p>
          <p>
            Built for students who want to take control of their academic journey with style and efficiency.
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;
