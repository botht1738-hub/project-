import FlowerDoodle from './decorative/FlowerDoodle';

function Stats() {
  return (
    <section className="relative px-8 py-16">
      <div className="max-w-5xl mx-auto">
        <p className="text-xs leading-relaxed mb-16 text-center max-w-3xl mx-auto text-justify">
          WOULD YOU LIKE TO INCREASE YOUR LEARNING EFFICIENCY, MASTER NEW SUBJECTS OR IMPROVE
          YOUR STUDY HABITS? STAND OUT IN YOUR ACADEMIC JOURNEY! KEEP ALL YOUR MATERIALS IN
          THE ONLINE SPACE! IT WILL HELP YOU STAY ORGANIZED, TRACK PROGRESS AND BE REMEMBERED BY EVERY VISITOR. WE
          UNDERSTAND THAT FIRST IMPRESSIONS ARE EVERYTHING, AND WE ENSURE THAT YOUR STUDY SPACE NOT ONLY
          MEETS YOUR NEEDS, BUT ALSO MAKES A LASTING IMPRESSION ON YOUR ACADEMIC JOURNEY.
        </p>

        <FlowerDoodle className="absolute right-8 top-32" style={{ transform: 'scale(1.2)' }} />

        <div className="flex justify-around items-start">
          <div className="text-center">
            <div className="pixel-text text-6xl mb-2">5+</div>
            <div className="text-xs">
              courses<br />organized
            </div>
          </div>

          <div className="text-center">
            <div className="pixel-text text-6xl mb-2">100+</div>
            <div className="text-xs">
              study hours<br />tracked
            </div>
          </div>

          <div className="text-center">
            <div className="pixel-text text-6xl mb-2">ALL</div>
            <div className="text-xs">
              semesters in<br />one dashboard
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Stats;
