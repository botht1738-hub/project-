function AnimatedWords() {
  const words = [
    'ACHIEVE',
    'SUCCEED',
    'FOCUS',
    'EXCEL',
    'GROW',
    'LEARN',
    'INSPIRE',
    'CREATE',
    'ADVANCE',
    'THRIVE'
  ];

  const repeatedWords1 = [...words, ...words];
  const repeatedWords2 = [...words, ...words];
  const repeatedWords3 = [...words, ...words];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Flow 1 - Top flowing path */}
      <div className="absolute w-full top-20 h-16 overflow-hidden">
        <div className="animate-flow-1 flex gap-8 whitespace-nowrap">
          {repeatedWords1.map((word, i) => (
            <span
              key={`flow1-${i}`}
              className="text-lg font-bold text-pink-500 opacity-80 flex-shrink-0"
              style={{ letterSpacing: '0.1em' }}
            >
              {word}
            </span>
          ))}
        </div>
      </div>

      {/* Flow 2 - Middle flowing path (opposite direction) */}
      <div className="absolute w-full top-1/2 h-16 overflow-hidden transform -translate-y-1/2">
        <div className="animate-flow-2 flex gap-8 whitespace-nowrap">
          {repeatedWords2.map((word, i) => (
            <span
              key={`flow2-${i}`}
              className="text-xl font-bold text-indigo-600 opacity-75 flex-shrink-0"
              style={{ letterSpacing: '0.1em' }}
            >
              {word}
            </span>
          ))}
        </div>
      </div>

      {/* Flow 3 - Bottom flowing path */}
      <div className="absolute w-full bottom-24 h-16 overflow-hidden">
        <div className="animate-flow-3 flex gap-8 whitespace-nowrap">
          {repeatedWords3.map((word, i) => (
            <span
              key={`flow3-${i}`}
              className="text-lg font-bold text-rose-400 opacity-70 flex-shrink-0"
              style={{ letterSpacing: '0.1em' }}
            >
              {word}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AnimatedWords;
