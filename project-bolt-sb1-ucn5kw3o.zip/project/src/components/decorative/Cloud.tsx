interface CloudProps {
  className?: string;
}

function Cloud({ className = '' }: CloudProps) {
  return (
    <svg
      viewBox="0 0 100 60"
      className={className}
      fill="white"
      opacity="0.7"
    >
      <ellipse cx="30" cy="40" rx="25" ry="20" />
      <ellipse cx="50" cy="30" rx="30" ry="25" />
      <ellipse cx="70" cy="40" rx="25" ry="20" />
      <rect x="10" y="40" width="80" height="20" />
    </svg>
  );
}

export default Cloud;
