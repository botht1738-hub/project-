interface StudyDinoProps {
  className?: string;
}

function StudyDino({ className = '' }: StudyDinoProps) {
  return (
    <svg
      viewBox="0 0 200 200"
      className={`w-48 h-48 ${className}`}
    >
      <g>
        <rect x="70" y="140" width="60" height="12" rx="6" fill="#333" />
        <circle cx="75" cy="152" r="8" fill="#333" />
        <circle cx="125" cy="152" r="8" fill="#333" />
        <circle cx="75" cy="152" r="5" fill="#555" />
        <circle cx="125" cy="152" r="5" fill="#555" />

        <ellipse cx="100" cy="100" rx="50" ry="45" fill="#4ADE80" stroke="#2D8A4F" strokeWidth="3" />

        <circle cx="85" cy="95" r="6" fill="#1F1F1F" />
        <circle cx="115" cy="95" r="6" fill="#1F1F1F" />

        <path d="M 85 110 Q 100 118 115 110" stroke="#2D8A4F" strokeWidth="2" fill="none" strokeLinecap="round" />

        <ellipse cx="70" cy="85" rx="12" ry="18" fill="#4ADE80" stroke="#2D8A4F" strokeWidth="2" />
        <ellipse cx="130" cy="85" rx="12" ry="18" fill="#4ADE80" stroke="#2D8A4F" strokeWidth="2" />

        <path d="M 10 50 L 20 40 L 30 45 L 40 35 L 50 40" stroke="#2D8A4F" strokeWidth="3" fill="none" />
        <path d="M 20 55 Q 30 50 35 55 Q 40 52 45 55" stroke="#2D8A4F" strokeWidth="2" fill="none" />

        <rect x="120" y="60" width="35" height="28" fill="#8B4513" stroke="#5D2E0F" strokeWidth="2" rx="2" />
        <rect x="122" y="62" width="31" height="24" fill="#F5F1E8" />
        <line x1="137" y1="62" x2="137" y2="86" stroke="#8B4513" strokeWidth="1" />
        <line x1="122" y1="74" x2="153" y2="74" stroke="#8B4513" strokeWidth="1" />

        <rect x="135" y="72" width="4" height="6" fill="#4ADE80" />
      </g>
    </svg>
  );
}

export default StudyDino;
