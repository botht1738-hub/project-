interface PixelatedDividerProps {
  flip?: boolean;
}

function PixelatedDivider({ flip = false }: PixelatedDividerProps) {
  const pixels = Array.from({ length: 50 }, (_, i) => {
    const height = Math.random() * 20 + 10;
    return height;
  });

  return (
    <div className={`relative w-full h-12 ${flip ? 'rotate-180' : ''}`}>
      <svg
        viewBox="0 0 1000 50"
        preserveAspectRatio="none"
        className="w-full h-full"
        style={{ display: 'block' }}
      >
        <defs>
          <pattern id="pixelPattern" x="0" y="0" width="20" height="50" patternUnits="userSpaceOnUse">
            {pixels.slice(0, 1).map((height, i) => (
              <rect
                key={i}
                x="0"
                y={50 - height}
                width="20"
                height={height}
                fill="#EC4899"
              />
            ))}
          </pattern>
        </defs>
        <rect width="1000" height="50" fill="#EC4899" />
        <g>
          {Array.from({ length: 50 }).map((_, i) => {
            const height = Math.sin(i * 0.5) * 15 + 20 + Math.random() * 10;
            return (
              <rect
                key={i}
                x={i * 20}
                y={50 - height}
                width="20"
                height={height}
                fill="#F5F1E8"
              />
            );
          })}
        </g>
      </svg>
    </div>
  );
}

export default PixelatedDivider;
