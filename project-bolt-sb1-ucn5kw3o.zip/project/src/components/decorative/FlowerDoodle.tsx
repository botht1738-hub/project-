interface FlowerDoodleProps {
  className?: string;
  style?: React.CSSProperties;
}

function FlowerDoodle({ className = '', style }: FlowerDoodleProps) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={`w-24 h-24 ${className}`}
      style={style}
    >
      <g stroke="#4ADE80" strokeWidth="3" fill="none">
        <circle cx="50" cy="30" r="8" />
        <circle cx="35" cy="45" r="8" />
        <circle cx="65" cy="45" r="8" />
        <circle cx="42" cy="62" r="8" />
        <circle cx="58" cy="62" r="8" />
        <circle cx="50" cy="50" r="6" fill="#4ADE80" />
        <path d="M 50 50 Q 30 70 25 90" strokeLinecap="round" />
        <path d="M 30 75 Q 20 75 15 80" strokeLinecap="round" />
        <path d="M 35 85 Q 40 90 45 85" strokeLinecap="round" />
      </g>
    </svg>
  );
}

export default FlowerDoodle;
