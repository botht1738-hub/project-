import PixelatedDivider from './decorative/PixelatedDivider';
import CourseCard from './CourseCard';

interface CoursesProps {
  onCourseClick: (courseId: string) => void;
}

function Courses({ onCourseClick }: CoursesProps) {
  const courses = [
    {
      id: 'cloud-computing',
      title: 'Cloud Computing Fundamentals',
      icon: 'cloud',
      description: 'Learn cloud infrastructure, deployment models, and cloud services.'
    },
    {
      id: 'project-management',
      title: 'Project Management and Acquisition',
      icon: 'briefcase',
      description: 'Master project planning, execution, and stakeholder management.'
    },
    {
      id: 'data-structures',
      title: 'Data Structures and Algorithms',
      icon: 'code',
      description: 'Deep dive into algorithms, data structures, and computational complexity.'
    },
    {
      id: 'network-security',
      title: 'Network Security and Management',
      icon: 'shield',
      description: 'Understand network protocols, security threats, and defense mechanisms.'
    },
    {
      id: 'probability-statistics',
      title: 'Probability and Statistics',
      icon: 'bar-chart-2',
      description: 'Explore probability theory, distributions, and statistical analysis.'
    },
    {
      id: 'public-speaking',
      title: 'Public Speaking',
      icon: 'mic',
      description: 'Develop presentation skills, audience engagement, and communication techniques.'
    }
  ];

  return (
    <>
      <PixelatedDivider />
      <section className="relative bg-pink-500 px-8 py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-center mb-16">
            <div className="pixel-text text-4xl mb-4 tracking-wider">study space</div>
            <div className="text-2xl font-light tracking-wide">for</div>
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {courses.map((course) => (
              <CourseCard
                key={course.id}
                {...course}
                onClick={() => onCourseClick(course.id)}
              />
            ))}
          </div>
        </div>
      </section>
      <PixelatedDivider flip />
    </>
  );
}

export default Courses;
