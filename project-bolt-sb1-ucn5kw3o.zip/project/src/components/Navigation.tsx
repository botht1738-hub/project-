function Navigation() {
  return (
    <nav className="relative z-10 px-8 py-6 flex justify-between items-center">
      <div className="text-sm font-bold tracking-tight">dino.lab</div>
      <div className="flex gap-12 text-xs">
        <a href="#services" className="hover:text-pink-500 transition-colors">our services</a>
        <a href="#about" className="hover:text-pink-500 transition-colors">who we are</a>
        <a href="#courses" className="hover:text-pink-500 transition-colors">courses for</a>
        <a href="#team" className="hover:text-pink-500 transition-colors">team</a>
        <a href="#contacts" className="hover:text-pink-500 transition-colors">contacts</a>
      </div>
    </nav>
  );
}

export default Navigation;
