import Cloud from './decorative/Cloud';
import FlowerDoodle from './decorative/FlowerDoodle';
import StudyDino from './decorative/StudyDino';
import AnimatedWords from './AnimatedWords';

function Hero() {
  return (
    <section className="relative px-8 py-20 overflow-hidden">
      <AnimatedWords />
      <FlowerDoodle className="absolute top-0 left-12" />
      <FlowerDoodle className="absolute top-32 right-32" style={{ transform: 'scale(0.8) rotate(45deg)' }} />

      <div className="max-w-4xl mx-auto text-center relative">
        <Cloud className="absolute -top-12 left-12 w-24 h-16 opacity-80" />
        <Cloud className="absolute -top-8 right-20 w-32 h-20 opacity-60" />
        <Cloud className="absolute top-12 left-32 w-20 h-14 opacity-70" />

        <h1 className="pixel-text text-[80px] leading-none mb-6 tracking-wider">
          STUDY<br />IS MY<br />SPACE
        </h1>

        <p className="text-2xl mb-8 font-light tracking-wide">
          ALL YOUR COURSES. ONE SMART PLACE.
        </p>

        <button className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-3 text-sm transition-colors">
          start studying
        </button>

        <StudyDino className="absolute -bottom-8 right-12" />
      </div>
    </section>
  );
}

export default Hero;
