import PixelIcon from './decorative/PixelIcon';

interface CourseCardProps {
  id: string;
  title: string;
  icon: string;
  description: string;
  onClick: () => void;
}

function CourseCard({ title, icon, description, onClick }: CourseCardProps) {
  return (
    <div
      className="bg-pink-400 p-6 hover:bg-pink-300 transition-colors group cursor-pointer"
      onClick={onClick}
    >
      <div className="mb-6 flex justify-center">
        <PixelIcon type={icon as any} />
      </div>

      <h3 className="text-sm font-bold mb-3 text-center">{title}</h3>

      <p className="text-[10px] leading-relaxed text-justify opacity-80">
        {description}
      </p>
    </div>
  );
}

export default CourseCard;
