import { useState, useEffect } from 'react';
import { ArrowLeft, Plus, Trash2, Check } from 'lucide-react';
import AnimatedWords from './AnimatedWords';
import PixelatedDivider from './decorative/PixelatedDivider';

interface CourseDetailProps {
  courseId: string;
  onBack: () => void;
}

interface Grade {
  id: string;
  type: 'quiz' | 'midterm';
  mark: number;
  total: number;
}

interface Todo {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
}

const courseNames: { [key: string]: string } = {
  'cloud-computing': 'Cloud Computing Fundamentals',
  'project-management': 'Project Management and Acquisition',
  'data-structures': 'Data Structures and Algorithms',
  'network-security': 'Network Security and Management',
  'probability-statistics': 'Probability and Statistics',
  'public-speaking': 'Public Speaking'
};

function CourseDetail({ courseId, onBack }: CourseDetailProps) {
  const [grades, setGrades] = useState<Grade[]>([
    { id: '1', type: 'quiz', mark: 85, total: 100 },
    { id: '2', type: 'midterm', mark: 78, total: 100 }
  ]);

  const [todos, setTodos] = useState<Todo[]>([
    { id: '1', title: 'Read Chapter 1-3', description: 'Complete readings for next class', completed: false },
    { id: '2', title: 'Complete Assignment 1', completed: false }
  ]);

  const [newGradeType, setNewGradeType] = useState<'quiz' | 'midterm'>('quiz');
  const [newGradeMark, setNewGradeMark] = useState('');
  const [newTodoTitle, setNewTodoTitle] = useState('');
  const [newTodoDesc, setNewTodoDesc] = useState('');

  const courseName = courseNames[courseId] || 'Course';

  const addGrade = () => {
    if (newGradeMark && parseFloat(newGradeMark) >= 0 && parseFloat(newGradeMark) <= 100) {
      const newGrade: Grade = {
        id: Date.now().toString(),
        type: newGradeType,
        mark: parseFloat(newGradeMark),
        total: 100
      };
      setGrades([...grades, newGrade]);
      setNewGradeMark('');
    }
  };

  const addTodo = () => {
    if (newTodoTitle.trim()) {
      const newTodo: Todo = {
        id: Date.now().toString(),
        title: newTodoTitle,
        description: newTodoDesc,
        completed: false
      };
      setTodos([...todos, newTodo]);
      setNewTodoTitle('');
      setNewTodoDesc('');
    }
  };

  const toggleTodoComplete = (id: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteGrade = (id: string) => {
    setGrades(grades.filter(g => g.id !== id));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  const averageGrade = grades.length > 0
    ? Math.round((grades.reduce((sum, g) => sum + g.mark, 0) / grades.length) * 10) / 10
    : 0;

  return (
    <section className="relative min-h-screen bg-pink-500 px-8 py-20">
      <AnimatedWords />

      <button
        onClick={onBack}
        className="absolute top-8 left-8 flex items-center gap-2 bg-pink-400 hover:bg-pink-300 px-4 py-2 transition-colors"
      >
        <ArrowLeft size={20} />
        Back
      </button>

      <div className="max-w-5xl mx-auto mt-12">
        <h1 className="pixel-text text-5xl mb-12 text-center tracking-wider">
          {courseName}
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <div className="bg-pink-400 p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <span className="text-3xl">📊</span> GRADES
              </h2>

              {grades.length > 0 && (
                <div className="mb-6 p-4 bg-pink-300 rounded">
                  <p className="text-sm font-bold">Average: <span className="text-xl">{averageGrade}%</span></p>
                </div>
              )}

              <div className="space-y-3 mb-6">
                {grades.map(grade => (
                  <div key={grade.id} className="flex items-center justify-between bg-pink-300 p-3 rounded">
                    <div>
                      <p className="font-bold capitalize text-sm">{grade.type}</p>
                      <p className="text-lg font-bold">{grade.mark}/{grade.total}</p>
                    </div>
                    <button
                      onClick={() => deleteGrade(grade.id)}
                      className="hover:text-red-600 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="space-y-3">
                <select
                  value={newGradeType}
                  onChange={(e) => setNewGradeType(e.target.value as 'quiz' | 'midterm')}
                  className="w-full px-3 py-2 border border-gray-400 bg-white text-sm"
                >
                  <option value="quiz">Quiz</option>
                  <option value="midterm">Midterm</option>
                </select>
                <input
                  type="number"
                  min="0"
                  max="100"
                  placeholder="Enter mark (0-100)"
                  value={newGradeMark}
                  onChange={(e) => setNewGradeMark(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-400 text-sm"
                />
                <button
                  onClick={addGrade}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 flex items-center justify-center gap-2 transition-colors font-bold text-sm"
                >
                  <Plus size={16} /> Add Grade
                </button>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-pink-400 p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <span className="text-3xl">✓</span> TO DO
              </h2>

              <div className="space-y-2 mb-6 max-h-64 overflow-y-auto">
                {todos.length === 0 ? (
                  <p className="text-sm text-gray-700 italic">No tasks yet. Add one to get started!</p>
                ) : (
                  todos.map(todo => (
                    <div
                      key={todo.id}
                      className="flex items-start gap-3 bg-pink-300 p-3 rounded"
                    >
                      <button
                        onClick={() => toggleTodoComplete(todo.id)}
                        className={`flex-shrink-0 mt-1 rounded border-2 w-5 h-5 flex items-center justify-center transition-all ${
                          todo.completed
                            ? 'bg-green-500 border-green-500'
                            : 'border-gray-400 hover:border-green-500'
                        }`}
                      >
                        {todo.completed && <Check size={14} className="text-white" />}
                      </button>
                      <div className="flex-grow">
                        <p className={`font-bold text-sm ${todo.completed ? 'line-through opacity-50' : ''}`}>
                          {todo.title}
                        </p>
                        {todo.description && (
                          <p className={`text-xs text-gray-700 ${todo.completed ? 'line-through opacity-50' : ''}`}>
                            {todo.description}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={() => deleteTodo(todo.id)}
                        className="flex-shrink-0 hover:text-red-600 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))
                )}
              </div>

              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Task title"
                  value={newTodoTitle}
                  onChange={(e) => setNewTodoTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-400 text-sm"
                  onKeyPress={(e) => e.key === 'Enter' && addTodo()}
                />
                <input
                  type="text"
                  placeholder="Task description (optional)"
                  value={newTodoDesc}
                  onChange={(e) => setNewTodoDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-400 text-sm"
                  onKeyPress={(e) => e.key === 'Enter' && addTodo()}
                />
                <button
                  onClick={addTodo}
                  className="w-full bg-green-500 hover:bg-green-600 text-white px-4 py-2 flex items-center justify-center gap-2 transition-colors font-bold text-sm"
                >
                  <Plus size={16} /> Add Task
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default CourseDetail;
